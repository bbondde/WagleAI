package com.sample.mask;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PointF;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.MapView;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.NaverMapOptions;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.UiSettings;
import com.naver.maps.map.overlay.InfoWindow;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.overlay.OverlayImage;
import com.naver.maps.map.util.FusedLocationSource;

public class MapsNaverActivity extends AppCompatActivity implements OnMapReadyCallback, Overlay.OnClickListener { //, NaverMap.OnMapClickListener, Overlay.OnClickListener, NaverMap.OnCameraChangeListener{

    private static final int ACCESSIBILITY_LOCATION_PERMISSION_REQUEST_CODE = 100;

    private FusedLocationSource locationSource;
    private MapView mapView;
    private NaverMap naverMap;
    private InfoWindow minfoWindow;
    private boolean mIsCameraAnimated = false;

    TextView  textView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_naver);

        textView = (TextView) findViewById(R.id.textView);

        mapView = findViewById(R.id.map_view);
        mapView.getMapAsync(this);
        //MapFragment mapFragment = (MapFragment)getSupportFragmentManager().findFragmentById(R.id.map);
        //mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {
        Marker marker = new Marker();
        marker.setPosition(new LatLng(37.5670135, 126.9783740));
        marker.setMap(naverMap);
        int a = 2;
        marker.setOnClickListener(new Overlay.OnClickListener() {
            @Override
            public boolean onClick(@NonNull Overlay overlay) {
                if (true) {
                    showMessage();
                }else {
                    showMessage1();
                }
                return false;
            }

        });
    }
    public void showMessage() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("이 곳의 밀집도");
        builder.setMessage("      사람이 많고, 밀집도가 높습니다");
        builder.setIcon(R.drawable.sorryface);
        builder.setNeutralButton("확인", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                Snackbar.make(textView,"       마스크를 꼭 착용해주세요~~ ", Snackbar.LENGTH_LONG).show();
            }
        });


        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void showMessage1() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("이 곳의 밀집도");
        builder.setMessage("       사람이 적고, 밀집도가 낮습니다");
        builder.setIcon(R.drawable.happyface);
        builder.setNeutralButton("확인", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                Snackbar.make(textView,"       마스크를 꼭 착용해주세요~~", Snackbar.LENGTH_LONG).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onClick(@NonNull Overlay overlay) {
        return false;
    }
}
    //private FragmentManager getSupportFragmentManager() {
    //}

//    @Override
//    public void onMapReady(@NonNull NaverMap naverMap) {
//        this.naverMap = naverMap;
//
//        locationSource = new FusedLocationSource(this, ACCESSIBILITY_LOCATION_PERMISSION_REQUEST_CODE);
//        naverMap.setLocationSource(locationSource);
//        UiSettings uiSettings =naverMap.getUiSettings();
//        uiSettings.setLocationButtonEnabled(true);
//
//        naverMap.addOnCameraChangeListener(this);
//        naverMap.setOnMapClickListener(this);
//
//        LatLng mapCenter = naverMap.getCameraPosition().target;
//
//         //인포윈도우 부분 꾸미기
//        minfoWindow = new InfoWindow();
//        minfoWindow.setAdapter(new InfoWindow.DefaultViewAdapter(this) {
//            @NonNull
//            @Override
//            protected View getContentView(@NonNull InfoWindow infoWindow) {
//                Marker marker = minfoWindow.getMarker();
//                View view = View.inflate(MapsNaverActivity.this, R.layout.view_info_window, null);
//                ((TextView) view.findViewById(R.id.name)).setText("사람 많고 밀집도 높음");
//                return view;
//            }
//        });
//    }
//    //마커 띄운 후 사라지게 하기
//    @Override
//    public void onMapClick(@NonNull PointF pointF, @NonNull LatLng latLng) {
//        if (minfoWindow.getMarker() != null) {
//            minfoWindow.close();
//            }
//    }
//    //지도가 이동시에 이동중임을 확인
//    @Override
//    public void onCameraChange(int reason, boolean animated) {
//        mIsCameraAnimated = animated;
//    }
//
//    //클릭시 마커 띄우기
//    @Override
//    public boolean onClick(@NonNull Overlay overlay) {
//        if (overlay instanceof Marker) {
//            Marker marker = (Marker) overlay;
//            if (marker.getInfoWindow() != null) {
//                //minfoWindow.close();
//                minfoWindow.open(marker);
//            } else {
//                minfoWindow.open(marker);
//            }
//            return true;
//        }
//        return false;
//    }



